import express, { type Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertPhotoSchema, insertVoteSchema } from "@shared/schema";
import { z } from "zod";

const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG, PNG, GIF, and WebP are allowed."));
    }
  },
});

async function seedDefaultCategories() {
  const existing = await storage.getCategories();
  if (existing.length === 0) {
    const defaultCategories = [
      { name: "Food", slug: "food", description: "Delicious dishes and culinary creations", type: "official_permanent" as const, icon: "utensils", isActive: true },
      { name: "Selfies", slug: "selfies", description: "Your best self-portraits", type: "official_permanent" as const, icon: "camera", isActive: true },
      { name: "Night Out", slug: "night-out", description: "Nightlife and party moments", type: "official_permanent" as const, icon: "moon", isActive: true },
      { name: "Photobooth", slug: "photobooth", description: "Fun photobooth moments", type: "official_permanent" as const, icon: "image", isActive: true },
      { name: "Hiking", slug: "hiking", description: "Trail adventures and nature walks", type: "official_permanent" as const, icon: "mountain", isActive: true },
      { name: "Family", slug: "family", description: "Precious family moments", type: "official_permanent" as const, icon: "users", isActive: true },
      { name: "Pets", slug: "pets", description: "Adorable pet photos", type: "official_permanent" as const, icon: "heart", isActive: true },
      { name: "Travel", slug: "travel", description: "Adventures around the world", type: "official_permanent" as const, icon: "plane", isActive: true },
      { name: "Golden Hour", slug: "golden-hour", description: "This week's challenge: Capture the magic of golden hour", type: "official_weekly" as const, icon: "sun", isActive: true, weekStart: new Date(), weekEnd: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) },
      { name: "Street Style", slug: "street-style", description: "This week's challenge: Urban fashion and street photography", type: "official_weekly" as const, icon: "shirt", isActive: true, weekStart: new Date(), weekEnd: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) },
    ];

    for (const cat of defaultCategories) {
      await storage.createCategory(cat);
    }
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);
  
  await seedDefaultCategories();

  app.use("/uploads", (req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    next();
  }, express.static(uploadDir));

  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUserWithBadges(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/categories", async (req, res) => {
    try {
      const cats = await storage.getActiveCategories();
      res.json(cats);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/archived", async (req, res) => {
    try {
      const cats = await storage.getArchivedCategories();
      res.json(cats);
    } catch (error) {
      console.error("Error fetching archived categories:", error);
      res.status(500).json({ message: "Failed to fetch archived categories" });
    }
  });

  app.get("/api/categories/:categoryId/top-photos", async (req, res) => {
    try {
      const { categoryId } = req.params;
      const photos = await storage.getTopPhotosForCategory(categoryId, 10);
      res.json(photos);
    } catch (error) {
      console.error("Error fetching top photos:", error);
      res.status(500).json({ message: "Failed to fetch top photos" });
    }
  });

  app.get("/api/photos", async (req: any, res) => {
    try {
      const { categoryId, sort } = req.query;
      const userId = req.user?.claims?.sub;
      
      const allPhotos = await storage.getPhotos({
        categoryId: categoryId as string,
        sort: sort as string,
      });

      const photosWithVotes = await Promise.all(
        allPhotos.map(async (photo) => {
          let userVote = 0;
          if (userId) {
            const vote = await storage.getVote(userId, photo.id);
            userVote = vote?.value || 0;
          }
          return { ...photo, userVote };
        })
      );

      res.json(photosWithVotes);
    } catch (error) {
      console.error("Error fetching photos:", error);
      res.status(500).json({ message: "Failed to fetch photos" });
    }
  });

  app.get("/api/photos/:photoId", async (req: any, res) => {
    try {
      const { photoId } = req.params;
      const userId = req.user?.claims?.sub;
      
      const photo = await storage.getPhotoById(photoId);
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }

      let userVote = 0;
      if (userId) {
        const vote = await storage.getVote(userId, photoId);
        userVote = vote?.value || 0;
      }

      res.json({ ...photo, userVote });
    } catch (error) {
      console.error("Error fetching photo:", error);
      res.status(500).json({ message: "Failed to fetch photo" });
    }
  });

  app.post("/api/photos", isAuthenticated, upload.single("image"), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      const userId = req.user.claims.sub;
      const { categoryId, caption } = req.body;

      if (!categoryId) {
        return res.status(400).json({ message: "Category is required" });
      }

      const category = await storage.getCategoryById(categoryId);
      if (!category) {
        return res.status(400).json({ message: "Invalid category" });
      }

      const imageUrl = `/uploads/${req.file.filename}`;

      const photo = await storage.createPhoto({
        userId,
        categoryId,
        imageUrl,
        caption: caption || null,
        isArchived: false,
      });

      res.json(photo);
    } catch (error) {
      console.error("Error uploading photo:", error);
      res.status(500).json({ message: "Failed to upload photo" });
    }
  });

  app.post("/api/photos/:photoId/vote", isAuthenticated, async (req: any, res) => {
    try {
      const { photoId } = req.params;
      const userId = req.user.claims.sub;
      
      const schema = z.object({ value: z.number().min(-1).max(1) });
      const { value } = schema.parse(req.body);

      const photo = await storage.getPhotoById(photoId);
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }

      const existingVote = await storage.getVote(userId, photoId);
      const previousValue = existingVote?.value || 0;

      if (value === 0) {
        if (existingVote) {
          await storage.deleteVote(userId, photoId);
        }
      } else {
        await storage.upsertVote({ userId, photoId, value });
      }

      let likeCount = photo.likeCount;
      let dislikeCount = photo.dislikeCount;

      if (previousValue === 1) likeCount--;
      if (previousValue === -1) dislikeCount--;
      if (value === 1) likeCount++;
      if (value === -1) dislikeCount++;

      const netVotes = likeCount - dislikeCount;
      await storage.updatePhotoVotes(photoId, likeCount, dislikeCount, netVotes);

      res.json({ success: true, likeCount, dislikeCount, netVotes });
    } catch (error) {
      console.error("Error voting:", error);
      res.status(500).json({ message: "Failed to vote" });
    }
  });

  app.patch("/api/photos/:photoId/archive", isAuthenticated, async (req: any, res) => {
    try {
      const { photoId } = req.params;
      const userId = req.user.claims.sub;

      const photo = await storage.getPhotoById(photoId);
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }
      if (photo.userId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }

      await storage.archivePhoto(photoId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error archiving photo:", error);
      res.status(500).json({ message: "Failed to archive photo" });
    }
  });

  app.delete("/api/photos/:photoId", isAuthenticated, async (req: any, res) => {
    try {
      const { photoId } = req.params;
      const userId = req.user.claims.sub;

      const photo = await storage.getPhotoById(photoId);
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }
      if (photo.userId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }

      await storage.deletePhoto(photoId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting photo:", error);
      res.status(500).json({ message: "Failed to delete photo" });
    }
  });

  app.get("/api/users/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const user = await storage.getUserWithBadges(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/users/:userId/photos", async (req: any, res) => {
    try {
      const { userId } = req.params;
      const currentUserId = req.user?.claims?.sub;
      const includeArchived = currentUserId === userId;

      const photos = await storage.getPhotos({ userId, includeArchived });
      
      const photosWithVotes = await Promise.all(
        photos.map(async (photo) => {
          let userVote = 0;
          if (currentUserId) {
            const vote = await storage.getVote(currentUserId, photo.id);
            userVote = vote?.value || 0;
          }
          return { ...photo, userVote };
        })
      );

      res.json(photosWithVotes);
    } catch (error) {
      console.error("Error fetching user photos:", error);
      res.status(500).json({ message: "Failed to fetch user photos" });
    }
  });

  app.get("/api/leaderboard/weekly", async (req, res) => {
    try {
      const leaderboard = await storage.getWeeklyLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching weekly leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  app.get("/api/leaderboard/category/:categoryId", async (req, res) => {
    try {
      const { categoryId } = req.params;
      const leaderboard = await storage.getCategoryLeaderboard(categoryId);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching category leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  app.get("/api/hall-of-fame/overall", async (req, res) => {
    try {
      const entries = await storage.getOverallHallOfFame();
      res.json(entries);
    } catch (error) {
      console.error("Error fetching overall hall of fame:", error);
      res.status(500).json({ message: "Failed to fetch hall of fame" });
    }
  });

  app.get("/api/hall-of-fame/category/:categoryId", async (req, res) => {
    try {
      const { categoryId } = req.params;
      const entries = await storage.getCategoryHallOfFame(categoryId);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching category hall of fame:", error);
      res.status(500).json({ message: "Failed to fetch hall of fame" });
    }
  });

  return httpServer;
}
