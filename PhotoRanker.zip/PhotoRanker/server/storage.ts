import {
  users,
  categories,
  photos,
  votes,
  badges,
  leaderboardEntries,
  hallOfFameEntries,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type Photo,
  type InsertPhoto,
  type Vote,
  type InsertVote,
  type Badge,
  type InsertBadge,
  type LeaderboardEntry,
  type InsertLeaderboardEntry,
  type HallOfFameEntry,
  type InsertHallOfFameEntry,
  type PhotoWithUser,
  type LeaderboardEntryWithUser,
  type HallOfFameEntryWithDetails,
  type UserWithBadges,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, sql, gte, lte, ne } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserWithBadges(id: string): Promise<UserWithBadges | undefined>;
  updateUserLeaderStatus(userId: string, isLeader: boolean): Promise<void>;
  
  getCategories(): Promise<Category[]>;
  getActiveCategories(): Promise<Category[]>;
  getArchivedCategories(): Promise<Category[]>;
  getCategoryById(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  getPhotos(options?: { categoryId?: string; userId?: string; sort?: string; includeArchived?: boolean }): Promise<PhotoWithUser[]>;
  getPhotoById(id: string): Promise<PhotoWithUser | undefined>;
  createPhoto(photo: InsertPhoto): Promise<Photo>;
  updatePhotoVotes(photoId: string, likeCount: number, dislikeCount: number, netVotes: number): Promise<void>;
  archivePhoto(photoId: string): Promise<void>;
  deletePhoto(photoId: string): Promise<void>;
  getTopPhotosForCategory(categoryId: string, limit?: number): Promise<PhotoWithUser[]>;
  
  getVote(userId: string, photoId: string): Promise<Vote | undefined>;
  upsertVote(vote: InsertVote): Promise<Vote>;
  deleteVote(userId: string, photoId: string): Promise<void>;
  
  getBadgesForUser(userId: string): Promise<Badge[]>;
  createBadge(badge: InsertBadge): Promise<Badge>;
  
  getWeeklyLeaderboard(): Promise<LeaderboardEntryWithUser[]>;
  getCategoryLeaderboard(categoryId: string): Promise<LeaderboardEntryWithUser[]>;
  createLeaderboardEntry(entry: InsertLeaderboardEntry): Promise<LeaderboardEntry>;
  
  getOverallHallOfFame(): Promise<HallOfFameEntryWithDetails[]>;
  getCategoryHallOfFame(categoryId: string): Promise<HallOfFameEntryWithDetails[]>;
  createHallOfFameEntry(entry: InsertHallOfFameEntry): Promise<HallOfFameEntry>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserWithBadges(id: string): Promise<UserWithBadges | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const userBadges = await this.getBadgesForUser(id);
    return {
      ...user,
      badgesList: userBadges,
    };
  }

  async updateUserLeaderStatus(userId: string, isLeader: boolean): Promise<void> {
    await db.update(users).set({ isCurrentLeader: isLeader }).where(eq(users.id, userId));
  }

  async getCategories(): Promise<Category[]> {
    return db.select().from(categories).orderBy(asc(categories.name));
  }

  async getActiveCategories(): Promise<Category[]> {
    return db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.name));
  }

  async getArchivedCategories(): Promise<Category[]> {
    return db.select().from(categories).where(eq(categories.isArchived, true)).orderBy(desc(categories.createdAt));
  }

  async getCategoryById(id: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [created] = await db.insert(categories).values(category).returning();
    return created;
  }

  async getPhotos(options: { categoryId?: string; userId?: string; sort?: string; includeArchived?: boolean } = {}): Promise<PhotoWithUser[]> {
    const conditions = [];
    
    if (options.categoryId) {
      conditions.push(eq(photos.categoryId, options.categoryId));
    }
    if (options.userId) {
      conditions.push(eq(photos.userId, options.userId));
    }
    if (!options.includeArchived) {
      conditions.push(eq(photos.isArchived, false));
    }

    const query = db
      .select()
      .from(photos)
      .leftJoin(users, eq(photos.userId, users.id))
      .leftJoin(categories, eq(photos.categoryId, categories.id))
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(photos.createdAt));

    const results = await query;

    return results.map((row) => ({
      ...row.photos,
      user: row.users!,
      category: row.categories!,
    }));
  }

  async getPhotoById(id: string): Promise<PhotoWithUser | undefined> {
    const [result] = await db
      .select()
      .from(photos)
      .leftJoin(users, eq(photos.userId, users.id))
      .leftJoin(categories, eq(photos.categoryId, categories.id))
      .where(eq(photos.id, id));

    if (!result) return undefined;

    return {
      ...result.photos,
      user: result.users!,
      category: result.categories!,
    };
  }

  async createPhoto(photo: InsertPhoto): Promise<Photo> {
    const [created] = await db.insert(photos).values(photo).returning();
    return created;
  }

  async updatePhotoVotes(photoId: string, likeCount: number, dislikeCount: number, netVotes: number): Promise<void> {
    await db.update(photos).set({ likeCount, dislikeCount, netVotes, updatedAt: new Date() }).where(eq(photos.id, photoId));
  }

  async archivePhoto(photoId: string): Promise<void> {
    await db.update(photos).set({ isArchived: true, updatedAt: new Date() }).where(eq(photos.id, photoId));
  }

  async deletePhoto(photoId: string): Promise<void> {
    await db.delete(votes).where(eq(votes.photoId, photoId));
    await db.delete(photos).where(eq(photos.id, photoId));
  }

  async getTopPhotosForCategory(categoryId: string, limit: number = 10): Promise<PhotoWithUser[]> {
    const results = await db
      .select()
      .from(photos)
      .leftJoin(users, eq(photos.userId, users.id))
      .leftJoin(categories, eq(photos.categoryId, categories.id))
      .where(and(eq(photos.categoryId, categoryId), eq(photos.isArchived, false)))
      .orderBy(desc(photos.netVotes))
      .limit(limit);

    return results.map((row) => ({
      ...row.photos,
      user: row.users!,
      category: row.categories!,
    }));
  }

  async getVote(userId: string, photoId: string): Promise<Vote | undefined> {
    const [vote] = await db
      .select()
      .from(votes)
      .where(and(eq(votes.userId, userId), eq(votes.photoId, photoId)));
    return vote;
  }

  async upsertVote(vote: InsertVote): Promise<Vote> {
    const existing = await this.getVote(vote.userId, vote.photoId);
    
    if (existing) {
      const [updated] = await db
        .update(votes)
        .set({ value: vote.value })
        .where(eq(votes.id, existing.id))
        .returning();
      return updated;
    }
    
    const [created] = await db.insert(votes).values(vote).returning();
    return created;
  }

  async deleteVote(userId: string, photoId: string): Promise<void> {
    await db.delete(votes).where(and(eq(votes.userId, userId), eq(votes.photoId, photoId)));
  }

  async getBadgesForUser(userId: string): Promise<Badge[]> {
    return db.select().from(badges).where(eq(badges.userId, userId)).orderBy(desc(badges.earnedAt));
  }

  async createBadge(badge: InsertBadge): Promise<Badge> {
    const [created] = await db.insert(badges).values(badge).returning();
    return created;
  }

  async getWeeklyLeaderboard(): Promise<LeaderboardEntryWithUser[]> {
    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);

    const results = await db
      .select({
        id: users.id,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        profileImageUrl: users.profileImageUrl,
        totalPoints: users.totalPoints,
        isCurrentLeader: users.isCurrentLeader,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        displayedBadges: users.displayedBadges,
        totalVotes: sql<number>`COALESCE(SUM(${photos.netVotes}), 0)::int`,
      })
      .from(photos)
      .leftJoin(users, eq(photos.userId, users.id))
      .leftJoin(categories, eq(photos.categoryId, categories.id))
      .where(
        and(
          eq(photos.isArchived, false),
          gte(photos.createdAt, weekStart),
          eq(categories.type, "official_weekly")
        )
      )
      .groupBy(users.id)
      .orderBy(sql`COALESCE(SUM(${photos.netVotes}), 0) DESC`)
      .limit(50);

    return results.map((row, index) => ({
      id: `weekly-${row.id}-${index}`,
      userId: row.id,
      categoryId: "",
      weekStart,
      weekEnd,
      rank: index + 1,
      points: Math.max(0, row.totalVotes * 10),
      totalVotes: row.totalVotes,
      createdAt: new Date(),
      user: {
        id: row.id,
        email: row.email,
        firstName: row.firstName,
        lastName: row.lastName,
        profileImageUrl: row.profileImageUrl,
        totalPoints: row.totalPoints || 0,
        displayedBadges: row.displayedBadges,
        isCurrentLeader: row.isCurrentLeader || false,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      },
    }));
  }

  async getCategoryLeaderboard(categoryId: string): Promise<LeaderboardEntryWithUser[]> {
    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);

    const results = await db
      .select({
        id: users.id,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        profileImageUrl: users.profileImageUrl,
        totalPoints: users.totalPoints,
        isCurrentLeader: users.isCurrentLeader,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        displayedBadges: users.displayedBadges,
        totalVotes: sql<number>`COALESCE(SUM(${photos.netVotes}), 0)::int`,
      })
      .from(photos)
      .leftJoin(users, eq(photos.userId, users.id))
      .where(and(eq(photos.categoryId, categoryId), eq(photos.isArchived, false)))
      .groupBy(users.id)
      .orderBy(sql`COALESCE(SUM(${photos.netVotes}), 0) DESC`)
      .limit(50);

    return results.map((row, index) => ({
      id: `cat-${categoryId}-${row.id}-${index}`,
      userId: row.id,
      categoryId,
      weekStart,
      weekEnd,
      rank: index + 1,
      points: Math.max(0, row.totalVotes * 10),
      totalVotes: row.totalVotes,
      createdAt: new Date(),
      user: {
        id: row.id,
        email: row.email,
        firstName: row.firstName,
        lastName: row.lastName,
        profileImageUrl: row.profileImageUrl,
        totalPoints: row.totalPoints || 0,
        displayedBadges: row.displayedBadges,
        isCurrentLeader: row.isCurrentLeader || false,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      },
    }));
  }

  async createLeaderboardEntry(entry: InsertLeaderboardEntry): Promise<LeaderboardEntry> {
    const [created] = await db.insert(leaderboardEntries).values(entry).returning();
    return created;
  }

  async getOverallHallOfFame(): Promise<HallOfFameEntryWithDetails[]> {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const results = await db
      .select()
      .from(photos)
      .leftJoin(users, eq(photos.userId, users.id))
      .leftJoin(categories, eq(photos.categoryId, categories.id))
      .where(eq(photos.isArchived, false))
      .orderBy(desc(photos.likeCount))
      .limit(10);

    return results.map((row, index) => ({
      id: `hof-overall-${row.photos.id}`,
      photoId: row.photos.id,
      userId: row.photos.userId,
      categoryId: row.photos.categoryId,
      monthStart,
      rank: index + 1,
      totalLikes: row.photos.likeCount,
      isOverall: true,
      createdAt: new Date(),
      photo: row.photos,
      user: row.users!,
      category: row.categories || undefined,
    }));
  }

  async getCategoryHallOfFame(categoryId: string): Promise<HallOfFameEntryWithDetails[]> {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const results = await db
      .select()
      .from(photos)
      .leftJoin(users, eq(photos.userId, users.id))
      .leftJoin(categories, eq(photos.categoryId, categories.id))
      .where(and(eq(photos.categoryId, categoryId), eq(photos.isArchived, false)))
      .orderBy(desc(photos.likeCount))
      .limit(10);

    return results.map((row, index) => ({
      id: `hof-cat-${categoryId}-${row.photos.id}`,
      photoId: row.photos.id,
      userId: row.photos.userId,
      categoryId,
      monthStart,
      rank: index + 1,
      totalLikes: row.photos.likeCount,
      isOverall: false,
      createdAt: new Date(),
      photo: row.photos,
      user: row.users!,
      category: row.categories || undefined,
    }));
  }

  async createHallOfFameEntry(entry: InsertHallOfFameEntry): Promise<HallOfFameEntry> {
    const [created] = await db.insert(hallOfFameEntries).values(entry).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
