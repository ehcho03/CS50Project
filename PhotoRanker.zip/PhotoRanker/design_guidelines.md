# Design Guidelines: Competitive Photo-Sharing Social Platform

## Design Approach
**Reference-Based:** Drawing from Instagram's visual-first feed design, TikTok's engagement mechanics, and gaming UI patterns for competitive elements (leaderboards, badges, achievements).

## Typography System
- **Primary Font:** Inter or DM Sans (Google Fonts) - clean, modern sans-serif
- **Hierarchy:**
  - Hero/Headers: Bold, 32-40px
  - Section Titles: Semibold, 24-28px
  - Body/Captions: Regular, 14-16px
  - Metadata/Stats: Medium, 12-14px
  - Badges/Labels: Bold, 10-12px uppercase with letter-spacing

## Layout System
**Spacing Units:** Tailwind spacing of 2, 4, 6, and 8 (with occasional 12, 16 for major sections)
- Component padding: p-4 to p-6
- Section spacing: gap-4 to gap-8
- Container max-widths: max-w-7xl for main content, max-w-md for mobile-optimized views

## Core Component Library

### Navigation
- **Top Bar:** Fixed header with logo, category selector dropdown, upload button (prominent), profile icon
- Height: h-16
- Shadow: subtle bottom shadow for depth
- Upload button: Rounded-full with icon, always visible

### Photo Grid System
- **Masonry/Grid Layout:** 3 columns desktop (grid-cols-3), 2 columns tablet (md:grid-cols-2), 1 column mobile
- Aspect ratio: Square (aspect-square) for consistency
- Card structure: Image with overlay on hover showing like count, category badge
- Gap between items: gap-4

### Category Navigation
- **Horizontal Scroll Pills:** Rounded-full buttons, active state clearly differentiated
- Official categories get special indicator (star icon or "Official" badge)
- Sticky below main nav (top-16)

### Leaderboard Component
- **Card-based ranks:** Each rank is a card with:
  - Rank number (large, bold) on left
  - Profile picture (rounded-full)
  - Username and points
  - Medal icons for top 3 (gold, silver, bronze visual treatment)
- Real-time indicator: Pulsing dot or "LIVE" badge
- Spacing: gap-3 between rank cards

### Profile Layout
- **Header Section:**
  - Profile picture: Large (w-24 h-24), centered, with "Leader Halo" (ring-4 with "Leader" text overlay) if applicable
  - Username below (text-xl font-bold)
  - Badge showcase: Horizontal row of 5 badge slots below username
  - Stats row: Uploads count, Hall of Fame entries, Leaderboard appearances

- **Badge Design:**
  - Rounded squares or shields (w-12 h-12)
  - Icon + number (for rank)
  - Tooltip on hover showing achievement details

- **Photo Gallery:** Same grid as main feed but showing user's uploads only

### Photo Upload Flow
- **Modal/Bottom Sheet:** Slides up from bottom on mobile, centered modal on desktop
- Camera roll selector OR camera capture interface
- Category dropdown (searchable)
- Visual preview of selected photo
- Submit button (large, rounded-lg)

### Photo Detail View
- **Full Screen Modal:**
  - Large image display (max-h-screen)
  - Like/dislike buttons (heart icon) prominent below image
  - Category tag, username, timestamp
  - Real-time like counter with animation on vote
  - Close button (top-right)

### Hall of Fame Display
- **Featured Showcase:**
  - Large hero card for #1 photo (aspect-video or aspect-square)
  - Grid of top 10 below (grid-cols-2 on mobile, grid-cols-5 on desktop)
  - Medal overlays on top 3
  - Monthly/Category tabs for navigation

### Sorting Controls
- **Tab System:** "Recent" | "Trending" | "Leaderboard"
- Clean underline animation for active tab
- Fixed below category pills when scrolling

## Interaction Patterns
- **Photo Cards:** Scale-up hover effect (hover:scale-105 transition)
- **Like Button:** Heart animation on tap/click
- **Leaderboard:** Auto-refresh every 10 seconds with subtle transition
- **Badge Collection:** Slot-based system showing earned badges with greyed-out slots for unearned

## Responsive Breakpoints
- Mobile: Base (< 768px) - Single column, bottom navigation
- Tablet: md (768px-1024px) - 2 column grids
- Desktop: lg (1024px+) - 3 column grids, side navigation

## Images
- **No hero image required** - This is a utility-focused social app
- **User-generated content** is the primary visual element
- Profile pictures: Circular thumbnails throughout
- Category thumbnails: Small icons or representative images in pills

## Key Visual Principles
- **Competition Focus:** Rankings and scores are visually prominent with large numbers and clear hierarchy
- **Real-time Energy:** Live indicators, animations on updates, dynamic leaderboards create urgency
- **Achievement Display:** Badges and halos are celebratory and eye-catching
- **Content First:** Photo grids dominate the layout with minimal chrome
- **Thumb-Friendly:** Large tap targets for voting, uploading, navigating (min h-12 for buttons)