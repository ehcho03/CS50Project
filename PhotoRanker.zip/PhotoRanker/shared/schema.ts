import { sql, relations } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const categoryTypeEnum = pgEnum("category_type", [
  "official_permanent",
  "official_weekly",
  "custom",
]);

export const badgeTypeEnum = pgEnum("badge_type", [
  "leaderboard_1st",
  "leaderboard_2nd",
  "leaderboard_3rd",
  "leaderboard_top10",
  "hall_of_fame_1st",
  "hall_of_fame_2nd",
  "hall_of_fame_3rd",
  "hall_of_fame_top10",
]);

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// Users table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  totalPoints: integer("total_points").default(0).notNull(),
  displayedBadges: text("displayed_badges").array().default(sql`ARRAY[]::text[]`),
  isCurrentLeader: boolean("is_current_leader").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Categories table
export const categories = pgTable("categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  type: categoryTypeEnum("type").notNull(),
  icon: varchar("icon", { length: 50 }),
  createdById: varchar("created_by_id").references(() => users.id),
  isActive: boolean("is_active").default(true).notNull(),
  weekStart: timestamp("week_start"),
  weekEnd: timestamp("week_end"),
  isArchived: boolean("is_archived").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Photos table
export const photos = pgTable("photos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  categoryId: varchar("category_id").notNull().references(() => categories.id),
  imageUrl: text("image_url").notNull(),
  caption: text("caption"),
  likeCount: integer("like_count").default(0).notNull(),
  dislikeCount: integer("dislike_count").default(0).notNull(),
  netVotes: integer("net_votes").default(0).notNull(),
  isArchived: boolean("is_archived").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_photos_category").on(table.categoryId),
  index("idx_photos_user").on(table.userId),
  index("idx_photos_net_votes").on(table.netVotes),
  index("idx_photos_created_at").on(table.createdAt),
]);

// Votes table
export const votes = pgTable("votes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  photoId: varchar("photo_id").notNull().references(() => photos.id),
  value: integer("value").notNull(), // 1 for like, -1 for dislike
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_votes_photo").on(table.photoId),
  index("idx_votes_user_photo").on(table.userId, table.photoId),
]);

// Leaderboard entries table (weekly snapshots)
export const leaderboardEntries = pgTable("leaderboard_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  categoryId: varchar("category_id").notNull().references(() => categories.id),
  weekStart: timestamp("week_start").notNull(),
  weekEnd: timestamp("week_end").notNull(),
  rank: integer("rank").notNull(),
  points: integer("points").notNull(),
  totalVotes: integer("total_votes").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_leaderboard_week").on(table.weekStart, table.weekEnd),
  index("idx_leaderboard_category").on(table.categoryId),
]);

// Badges table
export const badges = pgTable("badges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: badgeTypeEnum("type").notNull(),
  categoryId: varchar("category_id").references(() => categories.id),
  categoryName: varchar("category_name"),
  rank: integer("rank"),
  weekStart: timestamp("week_start"),
  monthStart: timestamp("month_start"),
  earnedAt: timestamp("earned_at").defaultNow(),
});

// Hall of Fame entries table
export const hallOfFameEntries = pgTable("hall_of_fame_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  photoId: varchar("photo_id").notNull().references(() => photos.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  categoryId: varchar("category_id").references(() => categories.id),
  monthStart: timestamp("month_start").notNull(),
  rank: integer("rank").notNull(),
  totalLikes: integer("total_likes").notNull(),
  isOverall: boolean("is_overall").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_hof_month").on(table.monthStart),
  index("idx_hof_category").on(table.categoryId),
]);

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  photos: many(photos),
  votes: many(votes),
  badges: many(badges),
  leaderboardEntries: many(leaderboardEntries),
  hallOfFameEntries: many(hallOfFameEntries),
  createdCategories: many(categories),
}));

export const categoriesRelations = relations(categories, ({ one, many }) => ({
  createdBy: one(users, {
    fields: [categories.createdById],
    references: [users.id],
  }),
  photos: many(photos),
  leaderboardEntries: many(leaderboardEntries),
  hallOfFameEntries: many(hallOfFameEntries),
}));

export const photosRelations = relations(photos, ({ one, many }) => ({
  user: one(users, {
    fields: [photos.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [photos.categoryId],
    references: [categories.id],
  }),
  votes: many(votes),
}));

export const votesRelations = relations(votes, ({ one }) => ({
  user: one(users, {
    fields: [votes.userId],
    references: [users.id],
  }),
  photo: one(photos, {
    fields: [votes.photoId],
    references: [photos.id],
  }),
}));

export const badgesRelations = relations(badges, ({ one }) => ({
  user: one(users, {
    fields: [badges.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [badges.categoryId],
    references: [categories.id],
  }),
}));

export const leaderboardEntriesRelations = relations(leaderboardEntries, ({ one }) => ({
  user: one(users, {
    fields: [leaderboardEntries.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [leaderboardEntries.categoryId],
    references: [categories.id],
  }),
}));

export const hallOfFameEntriesRelations = relations(hallOfFameEntries, ({ one }) => ({
  photo: one(photos, {
    fields: [hallOfFameEntries.photoId],
    references: [photos.id],
  }),
  user: one(users, {
    fields: [hallOfFameEntries.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [hallOfFameEntries.categoryId],
    references: [categories.id],
  }),
}));

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  createdAt: true,
});

export const insertPhotoSchema = createInsertSchema(photos).omit({
  id: true,
  likeCount: true,
  dislikeCount: true,
  netVotes: true,
  createdAt: true,
  updatedAt: true,
});

export const insertVoteSchema = createInsertSchema(votes).omit({
  id: true,
  createdAt: true,
});

export const insertBadgeSchema = createInsertSchema(badges).omit({
  id: true,
  earnedAt: true,
});

export const insertLeaderboardEntrySchema = createInsertSchema(leaderboardEntries).omit({
  id: true,
  createdAt: true,
});

export const insertHallOfFameEntrySchema = createInsertSchema(hallOfFameEntries).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Photo = typeof photos.$inferSelect;
export type InsertPhoto = z.infer<typeof insertPhotoSchema>;
export type Vote = typeof votes.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;
export type Badge = typeof badges.$inferSelect;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type LeaderboardEntry = typeof leaderboardEntries.$inferSelect;
export type InsertLeaderboardEntry = z.infer<typeof insertLeaderboardEntrySchema>;
export type HallOfFameEntry = typeof hallOfFameEntries.$inferSelect;
export type InsertHallOfFameEntry = z.infer<typeof insertHallOfFameEntrySchema>;

// Extended types for frontend
export type PhotoWithUser = Photo & {
  user: User;
  category: Category;
  userVote?: number;
};

export type LeaderboardEntryWithUser = LeaderboardEntry & {
  user: User;
};

export type HallOfFameEntryWithDetails = HallOfFameEntry & {
  photo: Photo;
  user: User;
  category?: Category;
};

export type UserWithBadges = User & {
  badgesList: Badge[];
};

export type CategoryWithStats = Category & {
  photoCount: number;
  topPhoto?: Photo;
};
