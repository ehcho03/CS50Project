import { useState } from "react";
import { Heart, ThumbsDown, X, Calendar, Tag, Share2, Trash2, Archive, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LeaderHalo } from "./LeaderHalo";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { PhotoWithUser } from "@shared/schema";
import { formatDistanceToNow, format } from "date-fns";

interface PhotoDetailModalProps {
  photo: PhotoWithUser | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  isOwner?: boolean;
  currentUserId?: string;
}

export function PhotoDetailModal({
  photo,
  open,
  onOpenChange,
  isOwner = false,
  currentUserId,
}: PhotoDetailModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [localVote, setLocalVote] = useState<number | null>(null);
  const [localLikeCount, setLocalLikeCount] = useState<number>(0);
  const [localDislikeCount, setLocalDislikeCount] = useState<number>(0);

  const currentVote = localVote ?? photo?.userVote ?? 0;
  const likeCount = localVote !== null ? localLikeCount : (photo?.likeCount ?? 0);
  const dislikeCount = localVote !== null ? localDislikeCount : (photo?.dislikeCount ?? 0);

  const voteMutation = useMutation({
    mutationFn: async ({ photoId, value }: { photoId: string; value: number }) => {
      await apiRequest("POST", `/api/photos/${photoId}/vote`, { value });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Sign in required",
          description: "Please sign in to vote on photos",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Vote failed",
        description: error.message,
        variant: "destructive",
      });
      setLocalVote(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (photoId: string) => {
      await apiRequest("DELETE", `/api/photos/${photoId}`);
    },
    onSuccess: () => {
      toast({
        title: "Photo deleted",
        description: "Your photo has been removed",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const archiveMutation = useMutation({
    mutationFn: async (photoId: string) => {
      await apiRequest("PATCH", `/api/photos/${photoId}/archive`);
    },
    onSuccess: () => {
      toast({
        title: "Photo archived",
        description: "Your photo has been archived",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Archive failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleVote = (value: number) => {
    if (!photo || !currentUserId) {
      toast({
        title: "Sign in required",
        description: "Please sign in to vote",
        variant: "destructive",
      });
      return;
    }

    const newValue = currentVote === value ? 0 : value;
    const prevVote = currentVote;
    
    let newLikeCount = photo.likeCount;
    let newDislikeCount = photo.dislikeCount;

    if (prevVote === 1) newLikeCount--;
    if (prevVote === -1) newDislikeCount--;
    if (newValue === 1) newLikeCount++;
    if (newValue === -1) newDislikeCount++;

    setLocalVote(newValue);
    setLocalLikeCount(newLikeCount);
    setLocalDislikeCount(newDislikeCount);

    voteMutation.mutate({ photoId: photo.id, value: newValue });
  };

  if (!photo) return null;

  const timeAgo = photo.createdAt
    ? formatDistanceToNow(new Date(photo.createdAt), { addSuffix: true })
    : "";

  const fullDate = photo.createdAt
    ? format(new Date(photo.createdAt), "MMMM d, yyyy 'at' h:mm a")
    : "";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl p-0 overflow-hidden max-h-[95vh]">
        <div className="relative">
          <img
            src={photo.imageUrl}
            alt={photo.caption || "Photo"}
            className="w-full max-h-[60vh] object-contain bg-black"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 bg-black/50 text-white hover:bg-black/70"
            onClick={() => onOpenChange(false)}
            data-testid="button-close-photo"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <LeaderHalo
                imageUrl={photo.user.profileImageUrl}
                firstName={photo.user.firstName}
                lastName={photo.user.lastName}
                isLeader={photo.user.isCurrentLeader}
                size="md"
              />
              <div>
                <p className="font-semibold">
                  {photo.user.firstName || "Anonymous"} {photo.user.lastName || ""}
                </p>
                <p className="text-sm text-muted-foreground" title={fullDate}>
                  {timeAgo}
                </p>
              </div>
            </div>
            {photo.category && (
              <Badge variant="secondary" className="gap-1">
                <Tag className="h-3 w-3" />
                {photo.category.name}
              </Badge>
            )}
          </div>

          {photo.caption && (
            <p className="text-sm">{photo.caption}</p>
          )}

          <div className="flex items-center justify-between pt-2 border-t">
            <div className="flex items-center gap-2">
              <Button
                variant={currentVote === 1 ? "default" : "outline"}
                size="sm"
                className={`gap-1.5 ${currentVote === 1 ? "bg-red-500 hover:bg-red-600 border-red-500" : ""}`}
                onClick={() => handleVote(1)}
                disabled={voteMutation.isPending}
                data-testid="button-like"
              >
                <Heart className={`h-4 w-4 ${currentVote === 1 ? "fill-current" : ""}`} />
                {likeCount}
              </Button>
              <Button
                variant={currentVote === -1 ? "default" : "outline"}
                size="sm"
                className={`gap-1.5 ${currentVote === -1 ? "bg-slate-500 hover:bg-slate-600 border-slate-500" : ""}`}
                onClick={() => handleVote(-1)}
                disabled={voteMutation.isPending}
                data-testid="button-dislike"
              >
                <ThumbsDown className={`h-4 w-4 ${currentVote === -1 ? "fill-current" : ""}`} />
                {dislikeCount}
              </Button>
            </div>

            <div className="flex items-center gap-2">
              {isOwner && (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => archiveMutation.mutate(photo.id)}
                    disabled={archiveMutation.isPending}
                    data-testid="button-archive"
                  >
                    {archiveMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Archive className="h-4 w-4" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => deleteMutation.mutate(photo.id)}
                    disabled={deleteMutation.isPending}
                    data-testid="button-delete"
                  >
                    {deleteMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Trash2 className="h-4 w-4" />
                    )}
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
