import { Star, Flame, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import type { Category } from "@shared/schema";

interface CategoryPillsProps {
  categories: Category[];
  selectedId?: string | null;
  onSelect: (categoryId: string | null) => void;
  showAll?: boolean;
  className?: string;
}

export function CategoryPills({
  categories,
  selectedId,
  onSelect,
  showAll = true,
  className = "",
}: CategoryPillsProps) {
  const officialPermanent = categories.filter(c => c.type === "official_permanent");
  const officialWeekly = categories.filter(c => c.type === "official_weekly" && c.isActive);

  return (
    <ScrollArea className={`w-full whitespace-nowrap ${className}`}>
      <div className="flex items-center gap-2 pb-2">
        {showAll && (
          <Button
            variant={selectedId === null ? "default" : "outline"}
            size="sm"
            className="rounded-full shrink-0"
            onClick={() => onSelect(null)}
            data-testid="category-all"
          >
            All
          </Button>
        )}
        
        {officialPermanent.map((category) => (
          <Button
            key={category.id}
            variant={selectedId === category.id ? "default" : "outline"}
            size="sm"
            className="rounded-full shrink-0 gap-1.5"
            onClick={() => onSelect(category.id)}
            data-testid={`category-${category.slug}`}
          >
            <Star className="h-3 w-3" />
            {category.name}
          </Button>
        ))}

        {officialWeekly.length > 0 && (
          <div className="h-4 w-px bg-border mx-1" />
        )}

        {officialWeekly.map((category) => (
          <Button
            key={category.id}
            variant={selectedId === category.id ? "default" : "outline"}
            size="sm"
            className="rounded-full shrink-0 gap-1.5 border-primary/50"
            onClick={() => onSelect(category.id)}
            data-testid={`category-${category.slug}`}
          >
            <Flame className="h-3 w-3 text-orange-500" />
            {category.name}
            <span className="text-[10px] uppercase font-bold tracking-wider text-orange-500">
              Weekly
            </span>
          </Button>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );
}

interface CategorySelectorProps {
  categories: Category[];
  selectedId?: string;
  onSelect: (categoryId: string) => void;
  className?: string;
}

export function CategorySelector({
  categories,
  selectedId,
  onSelect,
  className = "",
}: CategorySelectorProps) {
  return (
    <div className={`grid grid-cols-2 sm:grid-cols-3 gap-2 ${className}`}>
      {categories.map((category) => {
        const isWeekly = category.type === "official_weekly";
        const isSelected = selectedId === category.id;
        
        return (
          <Button
            key={category.id}
            variant={isSelected ? "default" : "outline"}
            className={`h-auto py-3 flex-col gap-1 ${
              isWeekly && !isSelected ? "border-primary/50" : ""
            }`}
            onClick={() => onSelect(category.id)}
            data-testid={`select-category-${category.slug}`}
          >
            <span className="flex items-center gap-1.5">
              {isWeekly ? (
                <Flame className="h-4 w-4 text-orange-500" />
              ) : (
                <Star className="h-4 w-4" />
              )}
              {category.name}
            </span>
            {isWeekly && (
              <span className="text-[10px] uppercase font-bold tracking-wider text-orange-500">
                Weekly Challenge
              </span>
            )}
          </Button>
        );
      })}
    </div>
  );
}
