import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Crown } from "lucide-react";

interface LeaderHaloProps {
  imageUrl?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  isLeader?: boolean;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

const sizeClasses = {
  sm: "h-8 w-8",
  md: "h-10 w-10",
  lg: "h-16 w-16",
  xl: "h-24 w-24",
};

const ringClasses = {
  sm: "ring-2",
  md: "ring-2",
  lg: "ring-4",
  xl: "ring-4",
};

const badgeSizes = {
  sm: "h-4 w-4 text-[8px]",
  md: "h-5 w-5 text-[9px]",
  lg: "h-7 w-7 text-[10px]",
  xl: "h-8 w-8 text-xs",
};

export function LeaderHalo({
  imageUrl,
  firstName,
  lastName,
  isLeader = false,
  size = "md",
  className = "",
}: LeaderHaloProps) {
  const initials = `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase() || "?";
  
  return (
    <div className={`relative inline-block ${className}`}>
      <Avatar
        className={`${sizeClasses[size]} ${
          isLeader
            ? `${ringClasses[size]} ring-amber-400 ring-offset-2 ring-offset-background`
            : ""
        }`}
      >
        <AvatarImage
          src={imageUrl || undefined}
          alt={`${firstName || ""} ${lastName || ""}`}
          className="object-cover"
        />
        <AvatarFallback className="bg-muted text-muted-foreground font-semibold">
          {initials}
        </AvatarFallback>
      </Avatar>
      {isLeader && (
        <div
          className={`absolute -top-1 -right-1 ${badgeSizes[size]} bg-amber-400 rounded-full flex items-center justify-center shadow-md`}
        >
          <Crown className="h-3 w-3 text-amber-900" />
        </div>
      )}
    </div>
  );
}
