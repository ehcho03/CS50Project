import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, TrendingUp, Trophy } from "lucide-react";

export type SortOption = "recent" | "trending" | "leaderboard";

interface SortingTabsProps {
  value: SortOption;
  onChange: (value: SortOption) => void;
  showLeaderboard?: boolean;
  className?: string;
}

export function SortingTabs({
  value,
  onChange,
  showLeaderboard = true,
  className = "",
}: SortingTabsProps) {
  return (
    <Tabs
      value={value}
      onValueChange={(v) => onChange(v as SortOption)}
      className={className}
    >
      <TabsList className="grid w-full max-w-sm" style={{ gridTemplateColumns: showLeaderboard ? 'repeat(3, 1fr)' : 'repeat(2, 1fr)' }}>
        <TabsTrigger value="recent" className="gap-1.5" data-testid="sort-recent">
          <Clock className="h-4 w-4" />
          Recent
        </TabsTrigger>
        <TabsTrigger value="trending" className="gap-1.5" data-testid="sort-trending">
          <TrendingUp className="h-4 w-4" />
          Trending
        </TabsTrigger>
        {showLeaderboard && (
          <TabsTrigger value="leaderboard" className="gap-1.5" data-testid="sort-leaderboard">
            <Trophy className="h-4 w-4" />
            Top
          </TabsTrigger>
        )}
      </TabsList>
    </Tabs>
  );
}
