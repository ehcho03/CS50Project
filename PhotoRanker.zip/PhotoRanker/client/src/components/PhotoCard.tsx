import { Heart, ThumbsDown, MessageCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { LeaderHalo } from "./LeaderHalo";
import type { PhotoWithUser } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface PhotoCardProps {
  photo: PhotoWithUser;
  onClick?: () => void;
  showCategory?: boolean;
  rank?: number;
}

export function PhotoCard({ photo, onClick, showCategory = true, rank }: PhotoCardProps) {
  const timeAgo = photo.createdAt
    ? formatDistanceToNow(new Date(photo.createdAt), { addSuffix: true })
    : "";

  return (
    <div
      className="group relative aspect-square rounded-md overflow-hidden cursor-pointer bg-muted"
      onClick={onClick}
      data-testid={`photo-card-${photo.id}`}
    >
      <img
        src={photo.imageUrl}
        alt={photo.caption || "Photo"}
        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        loading="lazy"
      />
      
      {rank && (
        <div className="absolute top-2 left-2 z-10">
          <div
            className={`h-8 w-8 rounded-full flex items-center justify-center font-bold text-sm shadow-lg ${
              rank === 1
                ? "bg-amber-400 text-amber-900"
                : rank === 2
                ? "bg-slate-300 text-slate-700"
                : rank === 3
                ? "bg-amber-600 text-amber-100"
                : "bg-card text-card-foreground"
            }`}
          >
            {rank}
          </div>
        </div>
      )}

      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />

      <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LeaderHalo
              imageUrl={photo.user.profileImageUrl}
              firstName={photo.user.firstName}
              lastName={photo.user.lastName}
              isLeader={photo.user.isCurrentLeader}
              size="sm"
            />
            <div className="text-white">
              <p className="text-sm font-medium leading-tight">
                {photo.user.firstName || "Anonymous"}
              </p>
              <p className="text-xs text-white/70">{timeAgo}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-white">
            <span className="flex items-center gap-1 text-sm">
              <Heart className={`h-4 w-4 ${photo.userVote === 1 ? "fill-red-500 text-red-500" : ""}`} />
              {photo.likeCount}
            </span>
          </div>
        </div>
      </div>

      {showCategory && photo.category && (
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="bg-black/50 text-white border-none backdrop-blur-sm">
            {photo.category.name}
          </Badge>
        </div>
      )}
    </div>
  );
}

export function PhotoCardSkeleton() {
  return (
    <div className="aspect-square rounded-md bg-muted animate-pulse" />
  );
}
