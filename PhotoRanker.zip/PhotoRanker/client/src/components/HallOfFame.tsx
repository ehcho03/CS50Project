import { Award, Crown, Medal, Star } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { LeaderHalo } from "./LeaderHalo";
import type { HallOfFameEntryWithDetails, Category } from "@shared/schema";

interface HallOfFameProps {
  entries: HallOfFameEntryWithDetails[];
  categories?: Category[];
  isLoading?: boolean;
  onPhotoClick?: (photoId: string) => void;
}

export function HallOfFame({
  entries,
  categories = [],
  isLoading = false,
  onPhotoClick,
}: HallOfFameProps) {
  const overallEntries = entries.filter((e) => e.isOverall);
  const categoryEntries = entries.filter((e) => !e.isOverall);

  const categoriesWithEntries = categories.filter((cat) =>
    categoryEntries.some((e) => e.categoryId === cat.id)
  );

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Award className="h-5 w-5 text-amber-500" />
            Hall of Fame
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            <div className="aspect-video bg-muted rounded-md" />
            <div className="grid grid-cols-3 gap-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="aspect-square bg-muted rounded-md" />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (entries.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Award className="h-5 w-5 text-amber-500" />
            Hall of Fame
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Star className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No Hall of Fame entries yet</p>
            <p className="text-sm">Top photos will appear here at month end</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Award className="h-5 w-5 text-amber-500" />
          Hall of Fame
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overall">
          <TabsList className="w-full mb-4">
            <TabsTrigger value="overall" className="flex-1" data-testid="hof-overall">
              Overall
            </TabsTrigger>
            {categoriesWithEntries.slice(0, 3).map((cat) => (
              <TabsTrigger
                key={cat.id}
                value={cat.id}
                className="flex-1"
                data-testid={`hof-${cat.slug}`}
              >
                {cat.name}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="overall">
            <HallOfFameGrid entries={overallEntries} onPhotoClick={onPhotoClick} />
          </TabsContent>

          {categoriesWithEntries.map((cat) => (
            <TabsContent key={cat.id} value={cat.id}>
              <HallOfFameGrid
                entries={categoryEntries.filter((e) => e.categoryId === cat.id)}
                onPhotoClick={onPhotoClick}
              />
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}

interface HallOfFameGridProps {
  entries: HallOfFameEntryWithDetails[];
  onPhotoClick?: (photoId: string) => void;
}

function HallOfFameGrid({ entries, onPhotoClick }: HallOfFameGridProps) {
  if (entries.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground text-sm">
        No entries in this category yet
      </div>
    );
  }

  const [first, ...rest] = entries;

  return (
    <div className="space-y-3">
      {first && (
        <div
          className="relative aspect-video rounded-md overflow-hidden cursor-pointer group"
          onClick={() => onPhotoClick?.(first.photoId)}
          data-testid={`hof-photo-${first.photoId}`}
        >
          <img
            src={first.photo.imageUrl}
            alt="Top photo"
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
          <div className="absolute top-2 left-2">
            <Badge className="bg-amber-400 text-amber-900 gap-1">
              <Crown className="h-3 w-3" />
              #1
            </Badge>
          </div>
          <div className="absolute bottom-3 left-3 right-3">
            <div className="flex items-center gap-2 text-white">
              <LeaderHalo
                imageUrl={first.user.profileImageUrl}
                firstName={first.user.firstName}
                lastName={first.user.lastName}
                size="sm"
              />
              <div>
                <p className="font-medium text-sm">
                  {first.user.firstName || "Anonymous"}
                </p>
                <p className="text-xs text-white/70">
                  {first.totalLikes.toLocaleString()} likes
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {rest.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
          {rest.slice(0, 9).map((entry) => (
            <div
              key={entry.id}
              className="relative aspect-square rounded-md overflow-hidden cursor-pointer group"
              onClick={() => onPhotoClick?.(entry.photoId)}
              data-testid={`hof-photo-${entry.photoId}`}
            >
              <img
                src={entry.photo.imageUrl}
                alt={`Rank ${entry.rank}`}
                className="w-full h-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div
                className={`absolute top-1 left-1 h-5 w-5 rounded-full flex items-center justify-center text-xs font-bold ${
                  entry.rank === 2
                    ? "bg-slate-300 text-slate-700"
                    : entry.rank === 3
                    ? "bg-amber-600 text-amber-100"
                    : "bg-card/90 text-card-foreground"
                }`}
              >
                {entry.rank}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
