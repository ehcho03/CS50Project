import { PhotoCard, PhotoCardSkeleton } from "./PhotoCard";
import type { PhotoWithUser } from "@shared/schema";

interface PhotoGridProps {
  photos: PhotoWithUser[];
  isLoading?: boolean;
  onPhotoClick?: (photo: PhotoWithUser) => void;
  showCategory?: boolean;
  showRanks?: boolean;
  emptyMessage?: string;
}

export function PhotoGrid({
  photos,
  isLoading = false,
  onPhotoClick,
  showCategory = true,
  showRanks = false,
  emptyMessage = "No photos yet. Be the first to upload!",
}: PhotoGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 9 }).map((_, i) => (
          <PhotoCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (photos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-4">
          <svg
            className="w-12 h-12 text-muted-foreground"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
            />
          </svg>
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-1">No Photos</h3>
        <p className="text-muted-foreground text-sm max-w-sm">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {photos.map((photo, index) => (
        <PhotoCard
          key={photo.id}
          photo={photo}
          onClick={() => onPhotoClick?.(photo)}
          showCategory={showCategory}
          rank={showRanks ? index + 1 : undefined}
        />
      ))}
    </div>
  );
}
