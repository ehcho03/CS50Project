import { Trophy, Medal, Award, Star, Crown } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import type { Badge } from "@shared/schema";

interface BadgeDisplayProps {
  badges: Badge[];
  maxDisplay?: number;
  size?: "sm" | "md" | "lg";
}

const badgeConfig: Record<string, { icon: typeof Trophy; color: string; label: string }> = {
  leaderboard_1st: { icon: Crown, color: "bg-amber-400 text-amber-900", label: "1st Place" },
  leaderboard_2nd: { icon: Medal, color: "bg-slate-300 text-slate-700", label: "2nd Place" },
  leaderboard_3rd: { icon: Medal, color: "bg-amber-600 text-amber-100", label: "3rd Place" },
  leaderboard_top10: { icon: Award, color: "bg-primary/20 text-primary", label: "Top 10" },
  hall_of_fame_1st: { icon: Trophy, color: "bg-amber-400 text-amber-900", label: "Hall of Fame #1" },
  hall_of_fame_2nd: { icon: Trophy, color: "bg-slate-300 text-slate-700", label: "Hall of Fame #2" },
  hall_of_fame_3rd: { icon: Trophy, color: "bg-amber-600 text-amber-100", label: "Hall of Fame #3" },
  hall_of_fame_top10: { icon: Star, color: "bg-primary/20 text-primary", label: "Hall of Fame Top 10" },
};

const sizeClasses = {
  sm: "h-8 w-8",
  md: "h-10 w-10",
  lg: "h-12 w-12",
};

const iconSizes = {
  sm: "h-4 w-4",
  md: "h-5 w-5",
  lg: "h-6 w-6",
};

export function BadgeDisplay({ badges, maxDisplay = 5, size = "md" }: BadgeDisplayProps) {
  const displayBadges = badges.slice(0, maxDisplay);
  const emptySlots = maxDisplay - displayBadges.length;

  return (
    <div className="flex items-center gap-2">
      {displayBadges.map((badge, index) => {
        const config = badgeConfig[badge.type] || badgeConfig.leaderboard_top10;
        const Icon = config.icon;
        const tooltipText = badge.categoryName
          ? `${config.label} - ${badge.categoryName}`
          : config.label;

        return (
          <Tooltip key={badge.id || index}>
            <TooltipTrigger asChild>
              <div
                className={`${sizeClasses[size]} ${config.color} rounded-md flex items-center justify-center cursor-default transition-transform hover:scale-110`}
                data-testid={`badge-${badge.type}-${index}`}
              >
                <Icon className={iconSizes[size]} />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p className="font-medium">{tooltipText}</p>
              {badge.rank && <p className="text-xs text-muted-foreground">Rank #{badge.rank}</p>}
            </TooltipContent>
          </Tooltip>
        );
      })}
      {Array.from({ length: emptySlots }).map((_, index) => (
        <div
          key={`empty-${index}`}
          className={`${sizeClasses[size]} bg-muted/50 border-2 border-dashed border-muted-foreground/20 rounded-md flex items-center justify-center`}
          data-testid={`badge-empty-${index}`}
        />
      ))}
    </div>
  );
}
