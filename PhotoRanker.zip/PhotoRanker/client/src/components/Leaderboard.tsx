import { Trophy, TrendingUp, Zap } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LeaderHalo } from "./LeaderHalo";
import type { LeaderboardEntryWithUser } from "@shared/schema";

interface LeaderboardProps {
  entries: LeaderboardEntryWithUser[];
  isLoading?: boolean;
  title?: string;
  showLiveBadge?: boolean;
  onUserClick?: (userId: string) => void;
}

export function Leaderboard({
  entries,
  isLoading = false,
  title = "Weekly Leaderboard",
  showLiveBadge = true,
  onUserClick,
}: LeaderboardProps) {
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-500" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 animate-pulse">
              <div className="w-8 h-8 rounded-full bg-muted" />
              <div className="h-10 w-10 rounded-full bg-muted" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-muted rounded w-24" />
                <div className="h-3 bg-muted rounded w-16" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (entries.length === 0) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-500" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <TrendingUp className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No rankings yet this week</p>
            <p className="text-sm">Be the first to compete!</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Trophy className="h-5 w-5 text-amber-500" />
          {title}
        </CardTitle>
        {showLiveBadge && (
          <Badge variant="outline" className="gap-1 text-xs">
            <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            LIVE
          </Badge>
        )}
      </CardHeader>
      <CardContent className="space-y-2">
        {entries.map((entry) => (
          <LeaderboardRow
            key={entry.id}
            entry={entry}
            onClick={() => onUserClick?.(entry.userId)}
          />
        ))}
      </CardContent>
    </Card>
  );
}

interface LeaderboardRowProps {
  entry: LeaderboardEntryWithUser;
  onClick?: () => void;
}

function LeaderboardRow({ entry, onClick }: LeaderboardRowProps) {
  const rankColors: Record<number, string> = {
    1: "bg-amber-400 text-amber-900",
    2: "bg-slate-300 text-slate-700",
    3: "bg-amber-600 text-amber-100",
  };

  const rankColor = rankColors[entry.rank] || "bg-muted text-muted-foreground";

  return (
    <div
      className="flex items-center gap-3 p-2 rounded-md hover-elevate cursor-pointer"
      onClick={onClick}
      data-testid={`leaderboard-row-${entry.rank}`}
    >
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${rankColor}`}
      >
        {entry.rank}
      </div>
      <LeaderHalo
        imageUrl={entry.user.profileImageUrl}
        firstName={entry.user.firstName}
        lastName={entry.user.lastName}
        isLeader={entry.rank === 1}
        size="sm"
      />
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">
          {entry.user.firstName || "Anonymous"} {entry.user.lastName?.[0] || ""}
        </p>
        <p className="text-xs text-muted-foreground">
          {entry.points.toLocaleString()} pts
        </p>
      </div>
      <div className="flex items-center gap-1 text-muted-foreground">
        <Zap className="h-4 w-4" />
        <span className="text-sm font-medium">{entry.totalVotes}</span>
      </div>
    </div>
  );
}
