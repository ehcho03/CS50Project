import { useState } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Camera, Trophy, Award, Calendar } from "lucide-react";
import { Header } from "@/components/Header";
import { LeaderHalo } from "@/components/LeaderHalo";
import { BadgeDisplay } from "@/components/BadgeDisplay";
import { PhotoGrid } from "@/components/PhotoGrid";
import { PhotoDetailModal } from "@/components/PhotoDetailModal";
import { PhotoUploadModal } from "@/components/PhotoUploadModal";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import type { UserWithBadges, PhotoWithUser, Category, Badge } from "@shared/schema";
import { format } from "date-fns";

export default function Profile() {
  const { user: currentUser } = useAuth();
  const [, params] = useRoute("/profile/:userId");
  const userId = params?.userId || currentUser?.id;
  const isOwnProfile = !params?.userId || params.userId === currentUser?.id;
  
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoWithUser | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const { data: profileUser, isLoading: userLoading } = useQuery<UserWithBadges>({
    queryKey: ["/api/users", userId],
    enabled: !!userId,
  });

  const { data: userPhotos = [], isLoading: photosLoading } = useQuery<PhotoWithUser[]>({
    queryKey: ["/api/users", userId, "photos"],
    enabled: !!userId,
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const activePhotos = userPhotos.filter((p) => !p.isArchived);
  const archivedPhotos = userPhotos.filter((p) => p.isArchived);

  const stats = [
    { label: "Photos", value: activePhotos.length, icon: Camera },
    { label: "Total Points", value: profileUser?.totalPoints || 0, icon: Trophy },
    { label: "Badges", value: profileUser?.badgesList?.length || 0, icon: Award },
  ];

  if (userLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={currentUser || null} onUploadClick={() => setUploadModalOpen(true)} />
        <main className="container px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col items-center text-center mb-8">
              <Skeleton className="h-24 w-24 rounded-full mb-4" />
              <Skeleton className="h-6 w-32 mb-2" />
              <Skeleton className="h-4 w-48" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!profileUser) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={currentUser || null} onUploadClick={() => setUploadModalOpen(true)} />
        <main className="container px-4 py-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-2xl font-bold mb-2">User Not Found</h1>
            <p className="text-muted-foreground">This profile doesn't exist.</p>
          </div>
        </main>
      </div>
    );
  }

  const joinDate = profileUser.createdAt
    ? format(new Date(profileUser.createdAt), "MMMM yyyy")
    : "";

  return (
    <div className="min-h-screen bg-background">
      <Header user={currentUser || null} onUploadClick={() => setUploadModalOpen(true)} />

      <main className="container px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col items-center text-center mb-8">
            <LeaderHalo
              imageUrl={profileUser.profileImageUrl}
              firstName={profileUser.firstName}
              lastName={profileUser.lastName}
              isLeader={profileUser.isCurrentLeader}
              size="xl"
              className="mb-4"
            />
            <h1 className="text-2xl font-bold mb-1" data-testid="text-profile-name">
              {profileUser.firstName || "Anonymous"} {profileUser.lastName || ""}
            </h1>
            {joinDate && (
              <p className="text-sm text-muted-foreground flex items-center gap-1 mb-4">
                <Calendar className="h-3 w-3" />
                Joined {joinDate}
              </p>
            )}
            
            <BadgeDisplay
              badges={profileUser.badgesList || []}
              maxDisplay={5}
              size="lg"
            />
          </div>

          <div className="grid grid-cols-3 gap-4 mb-8 max-w-md mx-auto">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <Card key={stat.label}>
                  <CardContent className="pt-4 pb-3 text-center">
                    <Icon className="h-5 w-5 mx-auto mb-1 text-muted-foreground" />
                    <div className="text-2xl font-bold">{stat.value.toLocaleString()}</div>
                    <div className="text-xs text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Tabs defaultValue="photos" className="w-full">
            <TabsList className="grid w-full max-w-xs mx-auto grid-cols-2 mb-6">
              <TabsTrigger value="photos" data-testid="tab-photos">
                Photos ({activePhotos.length})
              </TabsTrigger>
              {isOwnProfile && (
                <TabsTrigger value="archived" data-testid="tab-archived">
                  Archived ({archivedPhotos.length})
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="photos">
              <PhotoGrid
                photos={activePhotos}
                isLoading={photosLoading}
                onPhotoClick={setSelectedPhoto}
                emptyMessage={
                  isOwnProfile
                    ? "You haven't uploaded any photos yet. Click the upload button to get started!"
                    : "This user hasn't uploaded any photos yet."
                }
              />
            </TabsContent>

            {isOwnProfile && (
              <TabsContent value="archived">
                <PhotoGrid
                  photos={archivedPhotos}
                  isLoading={photosLoading}
                  onPhotoClick={setSelectedPhoto}
                  emptyMessage="No archived photos."
                />
              </TabsContent>
            )}
          </Tabs>
        </div>
      </main>

      <PhotoDetailModal
        photo={selectedPhoto}
        open={!!selectedPhoto}
        onOpenChange={(open) => !open && setSelectedPhoto(null)}
        isOwner={selectedPhoto?.userId === currentUser?.id}
        currentUserId={currentUser?.id}
      />

      <PhotoUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        categories={categories}
      />
    </div>
  );
}
