import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Award, Crown, Star, Calendar } from "lucide-react";
import { Header } from "@/components/Header";
import { PhotoUploadModal } from "@/components/PhotoUploadModal";
import { PhotoDetailModal } from "@/components/PhotoDetailModal";
import { LeaderHalo } from "@/components/LeaderHalo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import type { HallOfFameEntryWithDetails, Category, PhotoWithUser } from "@shared/schema";
import { format } from "date-fns";

export default function HallOfFamePage() {
  const { user } = useAuth();
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoWithUser | null>(null);

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: overallHof = [], isLoading: overallLoading } = useQuery<HallOfFameEntryWithDetails[]>({
    queryKey: ["/api/hall-of-fame/overall"],
  });

  const { data: categoryHof = [], isLoading: categoryLoading } = useQuery<HallOfFameEntryWithDetails[]>({
    queryKey: ["/api/hall-of-fame/category", selectedCategory],
    enabled: !!selectedCategory,
  });

  const handlePhotoClick = (entry: HallOfFameEntryWithDetails) => {
    const photoWithUser: PhotoWithUser = {
      ...entry.photo,
      user: entry.user,
      category: entry.category,
    };
    setSelectedPhoto(photoWithUser);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header user={user || null} onUploadClick={() => setUploadModalOpen(true)} />

      <main className="container px-4 py-6">
        <div className="max-w-5xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
              <Award className="h-8 w-8 text-amber-500" />
              Hall of Fame
            </h1>
            <p className="text-muted-foreground">
              The best photos of all time, crowned monthly
            </p>
          </div>

          <Tabs defaultValue="overall" className="space-y-6">
            <TabsList>
              <TabsTrigger value="overall" className="gap-2" data-testid="hof-tab-overall">
                <Crown className="h-4 w-4" />
                Overall
              </TabsTrigger>
              <TabsTrigger value="categories" className="gap-2" data-testid="hof-tab-categories">
                <Star className="h-4 w-4" />
                By Category
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overall" className="space-y-6">
              {overallLoading ? (
                <HofSkeleton />
              ) : overallHof.length === 0 ? (
                <EmptyHof />
              ) : (
                <HofDisplay entries={overallHof} onPhotoClick={handlePhotoClick} />
              )}
            </TabsContent>

            <TabsContent value="categories" className="space-y-6">
              <div className="flex flex-wrap gap-2 mb-4">
                {categories.filter(c => c.type !== "custom").map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    className="gap-1.5"
                    onClick={() => setSelectedCategory(
                      selectedCategory === category.id ? null : category.id
                    )}
                  >
                    <Star className="h-3 w-3" />
                    {category.name}
                  </Button>
                ))}
              </div>

              {selectedCategory ? (
                categoryLoading ? (
                  <HofSkeleton />
                ) : categoryHof.length === 0 ? (
                  <EmptyHof />
                ) : (
                  <HofDisplay entries={categoryHof} onPhotoClick={handlePhotoClick} />
                )
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  Select a category to view its Hall of Fame
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <PhotoUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        categories={categories}
      />

      <PhotoDetailModal
        photo={selectedPhoto}
        open={!!selectedPhoto}
        onOpenChange={(open) => !open && setSelectedPhoto(null)}
        currentUserId={user?.id}
      />
    </div>
  );
}

function HofDisplay({
  entries,
  onPhotoClick,
}: {
  entries: HallOfFameEntryWithDetails[];
  onPhotoClick: (entry: HallOfFameEntryWithDetails) => void;
}) {
  const [first, second, third, ...rest] = entries;

  return (
    <div className="space-y-8">
      {first && (
        <Card className="overflow-hidden">
          <div
            className="relative aspect-video cursor-pointer group"
            onClick={() => onPhotoClick(first)}
          >
            <img
              src={first.photo.imageUrl}
              alt="Top photo"
              className="w-full h-full object-cover transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute top-4 left-4">
              <Badge className="bg-amber-400 text-amber-900 gap-1 text-lg px-3 py-1">
                <Crown className="h-4 w-4" />
                #1
              </Badge>
            </div>
            <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
              <div className="flex items-center gap-3 text-white">
                <LeaderHalo
                  imageUrl={first.user.profileImageUrl}
                  firstName={first.user.firstName}
                  lastName={first.user.lastName}
                  size="lg"
                />
                <div>
                  <p className="font-bold text-xl">
                    {first.user.firstName || "Anonymous"} {first.user.lastName || ""}
                  </p>
                  <p className="text-white/70">
                    {first.totalLikes.toLocaleString()} likes
                  </p>
                </div>
              </div>
              {first.monthStart && (
                <Badge variant="secondary" className="bg-black/50 text-white border-none">
                  <Calendar className="h-3 w-3 mr-1" />
                  {format(new Date(first.monthStart), "MMMM yyyy")}
                </Badge>
              )}
            </div>
          </div>
        </Card>
      )}

      {(second || third) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[second, third].filter(Boolean).map((entry, idx) => entry && (
            <Card
              key={entry.id}
              className="overflow-hidden cursor-pointer group"
              onClick={() => onPhotoClick(entry)}
            >
              <div className="relative aspect-square">
                <img
                  src={entry.photo.imageUrl}
                  alt={`Rank ${idx + 2}`}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute top-3 left-3">
                  <Badge
                    className={`gap-1 ${
                      idx === 0
                        ? "bg-slate-300 text-slate-700"
                        : "bg-amber-600 text-amber-100"
                    }`}
                  >
                    #{idx + 2}
                  </Badge>
                </div>
                <div className="absolute bottom-3 left-3 right-3">
                  <div className="flex items-center gap-2 text-white">
                    <LeaderHalo
                      imageUrl={entry.user.profileImageUrl}
                      firstName={entry.user.firstName}
                      lastName={entry.user.lastName}
                      size="sm"
                    />
                    <div>
                      <p className="font-medium text-sm">
                        {entry.user.firstName || "Anonymous"}
                      </p>
                      <p className="text-xs text-white/70">
                        {entry.totalLikes.toLocaleString()} likes
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {rest.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4">Top 10</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {rest.slice(0, 7).map((entry) => (
              <div
                key={entry.id}
                className="relative aspect-square rounded-md overflow-hidden cursor-pointer group"
                onClick={() => onPhotoClick(entry)}
              >
                <img
                  src={entry.photo.imageUrl}
                  alt={`Rank ${entry.rank}`}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute top-1 left-1 h-6 w-6 rounded-full bg-card/90 flex items-center justify-center text-xs font-bold">
                  {entry.rank}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function HofSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="aspect-video rounded-md" />
      <div className="grid grid-cols-2 gap-4">
        <Skeleton className="aspect-square rounded-md" />
        <Skeleton className="aspect-square rounded-md" />
      </div>
    </div>
  );
}

function EmptyHof() {
  return (
    <div className="text-center py-16 text-muted-foreground">
      <Award className="h-16 w-16 mx-auto mb-4 opacity-50" />
      <h3 className="text-lg font-semibold mb-2">No Hall of Fame Entries Yet</h3>
      <p className="text-sm max-w-md mx-auto">
        The best photos will be inducted at the end of each month.
        Keep sharing and voting to help crown the champions!
      </p>
    </div>
  );
}
