import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/Header";
import { CategoryPills } from "@/components/CategoryPills";
import { PhotoGrid } from "@/components/PhotoGrid";
import { PhotoDetailModal } from "@/components/PhotoDetailModal";
import { PhotoUploadModal } from "@/components/PhotoUploadModal";
import { SortingTabs, type SortOption } from "@/components/SortingTabs";
import { Leaderboard } from "@/components/Leaderboard";
import { useAuth } from "@/hooks/useAuth";
import type { PhotoWithUser, Category, LeaderboardEntryWithUser } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortOption, setSortOption] = useState<SortOption>("recent");
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoWithUser | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const { data: categories = [], isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: photos = [], isLoading: photosLoading } = useQuery<PhotoWithUser[]>({
    queryKey: ["/api/photos", selectedCategory, sortOption],
  });

  const { data: leaderboard = [], isLoading: leaderboardLoading } = useQuery<LeaderboardEntryWithUser[]>({
    queryKey: ["/api/leaderboard/weekly"],
    refetchInterval: 10000,
  });

  const filteredPhotos = photos.filter((photo) => {
    if (selectedCategory && photo.categoryId !== selectedCategory) return false;
    return true;
  });

  const sortedPhotos = [...filteredPhotos].sort((a, b) => {
    if (sortOption === "recent") {
      return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
    }
    if (sortOption === "trending") {
      const aScore = a.netVotes / (Date.now() - new Date(a.createdAt || 0).getTime());
      const bScore = b.netVotes / (Date.now() - new Date(b.createdAt || 0).getTime());
      return bScore - aScore;
    }
    return b.netVotes - a.netVotes;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header user={user || null} onUploadClick={() => setUploadModalOpen(true)} />

      <main className="container px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 space-y-6">
            <div className="space-y-4">
              <CategoryPills
                categories={categories}
                selectedId={selectedCategory}
                onSelect={setSelectedCategory}
              />
              <SortingTabs value={sortOption} onChange={setSortOption} />
            </div>

            <PhotoGrid
              photos={sortedPhotos}
              isLoading={photosLoading || categoriesLoading}
              onPhotoClick={setSelectedPhoto}
              showCategory={!selectedCategory}
            />
          </div>

          <aside className="w-full lg:w-80 shrink-0">
            <div className="sticky top-20">
              <Leaderboard
                entries={leaderboard.slice(0, 10)}
                isLoading={leaderboardLoading}
                onUserClick={(userId) => {
                  window.location.href = `/profile/${userId}`;
                }}
              />
            </div>
          </aside>
        </div>
      </main>

      <PhotoDetailModal
        photo={selectedPhoto}
        open={!!selectedPhoto}
        onOpenChange={(open) => !open && setSelectedPhoto(null)}
        isOwner={selectedPhoto?.userId === user?.id}
        currentUserId={user?.id}
      />

      <PhotoUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        categories={categories}
      />
    </div>
  );
}
