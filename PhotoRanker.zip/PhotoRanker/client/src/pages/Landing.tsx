import { Camera, Trophy, Star, TrendingUp, Users, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function Landing() {
  const features = [
    {
      icon: Camera,
      title: "Share Your Best Shots",
      description: "Upload photos to official and weekly challenge categories",
    },
    {
      icon: Trophy,
      title: "Compete Weekly",
      description: "Climb the leaderboard with likes from the community",
    },
    {
      icon: Star,
      title: "Earn Badges",
      description: "Collect achievements for top performances",
    },
    {
      icon: Award,
      title: "Hall of Fame",
      description: "Get featured among the best photos of all time",
    },
  ];

  const stats = [
    { label: "Active Users", value: "10K+", icon: Users },
    { label: "Photos Shared", value: "50K+", icon: Camera },
    { label: "Weekly Challenges", value: "20+", icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-full bg-primary flex items-center justify-center">
              <Camera className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-xl">SnapRank</span>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Button asChild data-testid="button-get-started">
              <a href="/api/login">Get Started</a>
            </Button>
          </div>
        </div>
      </header>

      <main className="pt-16">
        <section className="relative py-20 md:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10" />
          <div className="container px-4 relative">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">
                Compete. Share.{" "}
                <span className="text-primary">Rise.</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Join the ultimate photo competition platform. Upload your best shots,
                compete in weekly challenges, and climb the leaderboard to earn
                exclusive badges.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-lg px-8" asChild data-testid="button-start-competing">
                  <a href="/api/login">Start Competing</a>
                </Button>
                <Button size="lg" variant="outline" className="text-lg px-8" asChild>
                  <a href="#features">Learn More</a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 border-y bg-muted/30">
          <div className="container px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {stats.map((stat) => {
                const Icon = stat.icon;
                return (
                  <div key={stat.label} className="text-center">
                    <Icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                    <div className="text-3xl font-bold">{stat.value}</div>
                    <div className="text-muted-foreground">{stat.label}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section id="features" className="py-20">
          <div className="container px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">How It Works</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                SnapRank combines the best of photo sharing with competitive gaming
                elements
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card key={index} className="hover-elevate">
                    <CardContent className="pt-6">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/30">
          <div className="container px-4">
            <div className="max-w-3xl mx-auto text-center">
              <Trophy className="h-16 w-16 mx-auto mb-6 text-amber-500" />
              <h2 className="text-3xl font-bold mb-4">Weekly Challenges</h2>
              <p className="text-muted-foreground mb-8">
                Every week, new official categories are announced. Compete against
                other photographers, earn points, and climb to the top of the
                leaderboard.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-lg mx-auto">
                <div className="p-4 rounded-md bg-amber-400/20 border border-amber-400/30">
                  <div className="text-2xl font-bold text-amber-600">1st</div>
                  <div className="text-sm text-muted-foreground">100 Points</div>
                </div>
                <div className="p-4 rounded-md bg-slate-300/30 border border-slate-400/30">
                  <div className="text-2xl font-bold text-slate-600">2nd</div>
                  <div className="text-sm text-muted-foreground">50 Points</div>
                </div>
                <div className="p-4 rounded-md bg-amber-600/20 border border-amber-600/30">
                  <div className="text-2xl font-bold text-amber-700">3rd</div>
                  <div className="text-sm text-muted-foreground">25 Points</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Compete?</h2>
            <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
              Join thousands of photographers showcasing their talent and competing
              for the top spots.
            </p>
            <Button size="lg" className="text-lg px-8" asChild data-testid="button-join-now">
              <a href="/api/login">Join Now</a>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Camera className="h-5 w-5 text-primary" />
            <span className="font-semibold">SnapRank</span>
          </div>
          <p className="text-sm text-muted-foreground">
            The ultimate photo competition platform
          </p>
        </div>
      </footer>
    </div>
  );
}
