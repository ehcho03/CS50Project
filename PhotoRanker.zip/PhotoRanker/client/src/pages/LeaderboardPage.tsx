import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Archive, Flame, Star } from "lucide-react";
import { Header } from "@/components/Header";
import { PhotoUploadModal } from "@/components/PhotoUploadModal";
import { LeaderHalo } from "@/components/LeaderHalo";
import { PhotoGrid } from "@/components/PhotoGrid";
import { PhotoDetailModal } from "@/components/PhotoDetailModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import type { LeaderboardEntryWithUser, Category, PhotoWithUser } from "@shared/schema";

export default function LeaderboardPage() {
  const { user } = useAuth();
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoWithUser | null>(null);

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: weeklyLeaderboard = [], isLoading: weeklyLoading } = useQuery<LeaderboardEntryWithUser[]>({
    queryKey: ["/api/leaderboard/weekly"],
    refetchInterval: 10000,
  });

  const { data: categoryLeaderboard = [], isLoading: categoryLoading } = useQuery<LeaderboardEntryWithUser[]>({
    queryKey: ["/api/leaderboard/category", selectedCategory],
    enabled: !!selectedCategory,
  });

  const { data: archivedCategories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories/archived"],
  });

  const { data: archivedPhotos = [] } = useQuery<PhotoWithUser[]>({
    queryKey: ["/api/categories", selectedCategory, "top-photos"],
    enabled: !!selectedCategory && archivedCategories.some(c => c.id === selectedCategory),
  });

  const weeklyCategories = categories.filter(c => c.type === "official_weekly" && c.isActive);
  const permanentCategories = categories.filter(c => c.type === "official_permanent");

  return (
    <div className="min-h-screen bg-background">
      <Header user={user || null} onUploadClick={() => setUploadModalOpen(true)} />

      <main className="container px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
              <Trophy className="h-8 w-8 text-amber-500" />
              Leaderboards
            </h1>
            <p className="text-muted-foreground">
              See who's leading the competition across all categories
            </p>
          </div>

          <Tabs defaultValue="weekly" className="space-y-6">
            <TabsList>
              <TabsTrigger value="weekly" className="gap-2" data-testid="tab-weekly">
                <Flame className="h-4 w-4" />
                Weekly
              </TabsTrigger>
              <TabsTrigger value="categories" className="gap-2" data-testid="tab-categories">
                <Star className="h-4 w-4" />
                By Category
              </TabsTrigger>
              <TabsTrigger value="archived" className="gap-2" data-testid="tab-archived">
                <Archive className="h-4 w-4" />
                Archived
              </TabsTrigger>
            </TabsList>

            <TabsContent value="weekly" className="space-y-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2">
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-amber-500" />
                    Weekly Leaderboard
                  </CardTitle>
                  <Badge variant="outline" className="gap-1">
                    <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                    LIVE
                  </Badge>
                </CardHeader>
                <CardContent>
                  {weeklyLoading ? (
                    <div className="space-y-3">
                      {Array.from({ length: 10 }).map((_, i) => (
                        <div key={i} className="flex items-center gap-3">
                          <Skeleton className="h-8 w-8 rounded-full" />
                          <Skeleton className="h-10 w-10 rounded-full" />
                          <div className="flex-1">
                            <Skeleton className="h-4 w-24 mb-1" />
                            <Skeleton className="h-3 w-16" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : weeklyLeaderboard.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No rankings this week yet. Be the first to compete!
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {weeklyLeaderboard.map((entry) => (
                        <LeaderboardRow key={entry.id} entry={entry} />
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {weeklyCategories.length > 0 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-semibold flex items-center gap-2">
                    <Flame className="h-5 w-5 text-orange-500" />
                    This Week's Categories
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {weeklyCategories.map((category) => (
                      <Card key={category.id} className="hover-elevate cursor-pointer">
                        <CardContent className="pt-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Flame className="h-4 w-4 text-orange-500" />
                            <span className="font-semibold">{category.name}</span>
                            <Badge variant="secondary" className="text-[10px]">
                              Weekly
                            </Badge>
                          </div>
                          {category.description && (
                            <p className="text-sm text-muted-foreground">
                              {category.description}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="categories" className="space-y-6">
              <div className="flex flex-wrap gap-2 mb-4">
                {permanentCategories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    className="gap-1.5"
                    onClick={() => setSelectedCategory(
                      selectedCategory === category.id ? null : category.id
                    )}
                  >
                    <Star className="h-3 w-3" />
                    {category.name}
                  </Button>
                ))}
              </div>

              {selectedCategory ? (
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {categories.find(c => c.id === selectedCategory)?.name} Leaderboard
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {categoryLoading ? (
                      <div className="space-y-3">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Skeleton key={i} className="h-14" />
                        ))}
                      </div>
                    ) : categoryLeaderboard.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        No rankings in this category yet.
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {categoryLeaderboard.map((entry) => (
                          <LeaderboardRow key={entry.id} entry={entry} />
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  Select a category to view its leaderboard
                </div>
              )}
            </TabsContent>

            <TabsContent value="archived" className="space-y-6">
              {archivedCategories.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Archive className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No archived categories yet.</p>
                  <p className="text-sm">Past weekly challenges will appear here.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {archivedCategories.map((category) => (
                      <Button
                        key={category.id}
                        variant={selectedCategory === category.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(
                          selectedCategory === category.id ? null : category.id
                        )}
                      >
                        {category.name}
                      </Button>
                    ))}
                  </div>

                  {selectedCategory && (
                    <div>
                      <h3 className="text-lg font-semibold mb-4">
                        Top 10 Photos
                      </h3>
                      <PhotoGrid
                        photos={archivedPhotos.slice(0, 10)}
                        onPhotoClick={setSelectedPhoto}
                        showRanks
                      />
                    </div>
                  )}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <PhotoUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        categories={categories}
      />

      <PhotoDetailModal
        photo={selectedPhoto}
        open={!!selectedPhoto}
        onOpenChange={(open) => !open && setSelectedPhoto(null)}
        currentUserId={user?.id}
      />
    </div>
  );
}

function LeaderboardRow({ entry }: { entry: LeaderboardEntryWithUser }) {
  const rankColors: Record<number, string> = {
    1: "bg-amber-400 text-amber-900",
    2: "bg-slate-300 text-slate-700",
    3: "bg-amber-600 text-amber-100",
  };

  return (
    <div className="flex items-center gap-3 p-3 rounded-md hover-elevate">
      <div
        className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
          rankColors[entry.rank] || "bg-muted text-muted-foreground"
        }`}
      >
        {entry.rank}
      </div>
      <LeaderHalo
        imageUrl={entry.user.profileImageUrl}
        firstName={entry.user.firstName}
        lastName={entry.user.lastName}
        isLeader={entry.rank === 1}
        size="md"
      />
      <div className="flex-1 min-w-0">
        <p className="font-medium truncate">
          {entry.user.firstName || "Anonymous"} {entry.user.lastName || ""}
        </p>
        <p className="text-sm text-muted-foreground">
          {entry.points.toLocaleString()} points
        </p>
      </div>
      <div className="text-right">
        <p className="font-medium">{entry.totalVotes}</p>
        <p className="text-xs text-muted-foreground">votes</p>
      </div>
    </div>
  );
}
