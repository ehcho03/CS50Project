# SnapRank - Competitive Photo Sharing Platform

## Overview
SnapRank is a social media photo-sharing platform where users compete in weekly challenges, earn badges, and climb leaderboards. Users can upload photos to various categories (both permanent and weekly rotating), vote on other users' photos, and earn recognition through the Hall of Fame system.

## Tech Stack
- **Frontend**: React, TypeScript, Tailwind CSS, Shadcn UI
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL (Neon) with Drizzle ORM
- **Authentication**: Replit Auth (OpenID Connect)
- **File Storage**: Local filesystem with multer

## Project Structure
```
├── client/src/
│   ├── components/         # Reusable UI components
│   │   ├── BadgeDisplay.tsx
│   │   ├── CategoryPills.tsx
│   │   ├── HallOfFame.tsx
│   │   ├── Header.tsx
│   │   ├── Leaderboard.tsx
│   │   ├── LeaderHalo.tsx
│   │   ├── PhotoCard.tsx
│   │   ├── PhotoDetailModal.tsx
│   │   ├── PhotoGrid.tsx
│   │   ├── PhotoUploadModal.tsx
│   │   ├── SortingTabs.tsx
│   │   ├── ThemeProvider.tsx
│   │   └── ThemeToggle.tsx
│   ├── hooks/
│   │   └── useAuth.ts      # Authentication hook
│   ├── lib/
│   │   ├── authUtils.ts    # Auth helper functions
│   │   └── queryClient.ts  # TanStack Query setup
│   ├── pages/
│   │   ├── Landing.tsx     # Landing page for unauthenticated users
│   │   ├── Home.tsx        # Main feed for authenticated users
│   │   ├── Profile.tsx     # User profile with badges and photos
│   │   ├── LeaderboardPage.tsx
│   │   ├── HallOfFamePage.tsx
│   │   └── not-found.tsx
│   └── App.tsx             # Main app with routing
├── server/
│   ├── db.ts               # Database connection
│   ├── index.ts            # Express app entry
│   ├── replitAuth.ts       # Replit Auth setup
│   ├── routes.ts           # API endpoints
│   └── storage.ts          # Database operations
├── shared/
│   └── schema.ts           # Database schema and types
└── uploads/                # User uploaded images
```

## Database Schema
- **users**: User profiles with points and badges
- **sessions**: Session storage for auth
- **categories**: Photo categories (official permanent, official weekly, custom)
- **photos**: User uploaded photos
- **votes**: Like/dislike votes on photos
- **badges**: Achievement badges earned by users
- **leaderboard_entries**: Weekly leaderboard rankings
- **hall_of_fame_entries**: Monthly hall of fame rankings

## Key Features
1. **Categories**
   - Official Permanent: Food, Selfies, Night Out, Photobooth, Hiking, Family, Pets, Travel
   - Official Weekly: Rotating challenges (e.g., Golden Hour, Street Style)
   - Custom categories (future feature)

2. **Voting System**
   - Like/dislike photos
   - Net votes determine ranking
   - Trending algorithm based on vote velocity

3. **Leaderboards**
   - Weekly leaderboard with point allocation (1st: 100pts, 2nd: 50pts, 3rd: 25pts)
   - Category-specific leaderboards
   - Real-time updates

4. **Hall of Fame**
   - Monthly recognition for top photos
   - Overall and category-specific halls

5. **Badges**
   - Leaderboard achievements (1st, 2nd, 3rd, Top 10)
   - Hall of Fame achievements
   - Display up to 5 badges on profile

6. **Leader Halo**
   - Special visual indicator for current leaderboard leaders

## API Endpoints
- `GET /api/auth/user` - Get current user
- `GET /api/categories` - List active categories
- `GET /api/photos` - List photos with optional filters
- `POST /api/photos` - Upload a new photo
- `POST /api/photos/:id/vote` - Vote on a photo
- `PATCH /api/photos/:id/archive` - Archive a photo
- `DELETE /api/photos/:id` - Delete a photo
- `GET /api/users/:id` - Get user profile
- `GET /api/users/:id/photos` - Get user's photos
- `GET /api/leaderboard/weekly` - Get weekly leaderboard
- `GET /api/hall-of-fame/overall` - Get overall hall of fame

## Running the Project
```bash
npm run dev     # Start development server
npm run db:push # Push schema changes to database
```

## Environment Variables
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Session encryption key
- `ISSUER_URL` - Replit OIDC issuer URL
- `REPL_ID` - Replit application ID
